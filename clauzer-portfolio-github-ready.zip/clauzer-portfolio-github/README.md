# CLAUZER — Fantasy Character Artist

GitHub Pages-ready version of the CLAUZER portfolio.

## Important
All files, including artwork images, belong in the repository root. `index.html` references the images directly by filename (for example `vanir-scene.webp`).

## GitHub Pages
1. Upload all files in this folder to the root of the repository.
2. In **Settings → Pages**, choose **Deploy from a branch**.
3. Select `main` and `/ (root)`.
4. Save and wait a few minutes for deployment.
